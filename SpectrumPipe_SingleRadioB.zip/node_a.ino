#include "SpectrumPipeCommon.h"

// Spectrum-Pipe Node A — source endpoint
// One nRF24. Node B is the single-radio relay/master.

RF24 radio(RF_CE_PIN, RF_CSN_PIN);
static uint8_t blacklist[BLACKLIST_BYTES];
static bool synced=false;
static int32_t clockOffsetUs=0;
static uint32_t lastSyncMs=0;
static uint32_t currentSF=0;
static uint16_t mapVersion=1;
static uint16_t nextMsgId=1;
static uint16_t txMsgId=0;
static uint8_t txFrag=0;
static uint8_t txTotal=0;
static char txMessage[256];
static uint16_t txMessageLen=0;
static uint32_t lastTxSF=0xFFFFFFFFUL;
static uint32_t lastAckSF=0;
static uint32_t sentFragments=0, custodyAcks=0, delivered=0, retries=0;
static uint8_t currentChannel=RF_CHANNEL_SYNC;

struct RxMessage { uint16_t msgId; uint8_t total; uint8_t got[32]; char data[256]; uint16_t len; bool active; };
static RxMessage rxMsg={};

static void emitStats() {
  Serial.printf("STAT|A|sync=%u|sf=%lu|ch=%u|map=%u|tx=%lu|custody=%lu|del=%lu|retry=%lu\n",
    synced, (unsigned long)currentSF, currentChannel, mapVersion,
    (unsigned long)sentFragments,(unsigned long)custodyAcks,(unsigned long)delivered,(unsigned long)retries);
}

static void queueText(const char *s) {
  if (!s || !*s) return;
  size_t n=strlen(s); if(n>sizeof(txMessage)) n=sizeof(txMessage);
  memcpy(txMessage,s,n); txMessageLen=n;
  txMsgId=nextMsgId++;
  txFrag=0;
  txTotal=(uint8_t)((txMessageLen + DATA_PLAINTEXT_MAX-1)/DATA_PLAINTEXT_MAX);
  if(txTotal==0) txTotal=1;
  Serial.printf("QUEUE|A|msg=%u|bytes=%u|frags=%u\n",txMsgId,txMessageLen,txTotal);
}

static void sendSyncRecovery() {
  setRadioChannel(radio, RF_CHANNEL_SYNC);
}

static void handleSync(const SyncFrame &s) {
  if(!validHeader(s.magic,s.version,s.type,s.src,s.dst) || s.src!=NODE_B || s.type!=FT_SYNC) return;
  memcpy(blacklist,s.blacklist,BLACKLIST_BYTES);
  mapVersion=s.mapVersion;
  uint32_t localAtRx=micros();
  // B puts its send timestamp in the superframe schedule by making the beacon the frame anchor.
  // We align our logical clock to the received superframe counter, not to wall-clock duration.
  currentSF=s.sf;
  clockOffsetUs=(int32_t)(s.sf*SUPERFRAME_US) - (int32_t)localAtRx;
  synced=true; lastSyncMs=millis();
  Serial.printf("SYNC|A|sf=%lu|map=%u|blacklist=%u\n",(unsigned long)currentSF,mapVersion,blCount(blacklist));
}

static uint32_t logicalUs(){ return (uint32_t)((int64_t)micros()+clockOffsetUs); }

static void processAck(const AckFrame &a) {
  if(!validHeader(a.magic,a.version,a.type,a.src,a.dst)) return;
  if(a.dst!=NODE_A) return;
  if(a.type==FT_CUSTODY && a.msgId==txMsgId && a.frag==txFrag) {
    custodyAcks++;
    if(txFrag+1<txTotal) txFrag++;
    else { txMessageLen=0; txFrag=0; txTotal=0; }
  }
  emitStats();
}

static void sendDataFragment(uint32_t sf) {
  if(txMessageLen==0 || txTotal==0) return;
  uint8_t offset=txFrag*DATA_PLAINTEXT_MAX;
  if(offset>=txMessageLen) return;
  uint8_t len=(uint8_t)min((uint16_t)DATA_PLAINTEXT_MAX,(uint16_t)(txMessageLen-offset));
  DataFrame f{};
  f.magic=SP_MAGIC; f.version=SP_VERSION; f.type=FT_DATA; f.src=NODE_A; f.dst=NODE_B;
  f.sf=sf; f.msgId=txMsgId; f.frag=txFrag; f.total=txTotal; f.flags=1; f.len=len;
  if(!gcmEncrypt((uint8_t*)txMessage+offset,len,f.ciphertext,f.tag,NODE_A,NODE_C,sf,txMsgId,txFrag)) return;
  setRadioChannel(radio,hopChannel(sf,FHSS_SEED_AB,blacklist));
  currentChannel=radio.getChannel();
  if(txFrame(radio,&f)) sentFragments++; else retries++;
  lastTxSF=sf;
}

static void receiveDownlink(uint32_t sf) {
  uint32_t end=micros()+2500;
  while((int32_t)(micros()-end)<0 && radio.available()) {
    uint8_t raw[32]; radio.read(raw,32);
    uint8_t type=raw[3];
    if(type==FT_CUSTODY || type==FT_DELIVERY) { AckFrame a; memcpy(&a,raw,32); processAck(a); }
    else if(type==FT_DATA) {
      DataFrame d; memcpy(&d,raw,32);
      if(d.src==NODE_B && d.dst==NODE_A && d.type==FT_DATA && d.len<=DATA_PLAINTEXT_MAX) {
        uint8_t plain[8];
        // Reverse-path ciphertext was created at C for A.
        if(gcmDecrypt(d.ciphertext,d.len,d.tag,plain,NODE_C,NODE_A,d.sf,d.msgId,d.frag)) {
          // Return-path demo messages are printed; larger application buffering can be added without changing RF protocol.
          Serial.printf("RX|A|msg=%u|frag=%u|data=",d.msgId,d.frag);
          for(uint8_t i=0;i<d.len;i++) Serial.write(plain[i]);
          Serial.println();
          AckFrame ack{}; ack.magic=SP_MAGIC; ack.version=SP_VERSION; ack.type=FT_DELIVERY;
          ack.src=NODE_A; ack.dst=NODE_B; ack.sf=sf; ack.msgId=d.msgId; ack.frag=d.frag; ack.code=2;
          setRadioChannel(radio,hopChannel(sf,FHSS_SEED_AB,blacklist)); txFrame(radio,&ack);
          delivered++;
        }
      }
    }
  }
}

static void tryRendezvous() {
  setRadioChannel(radio,RF_CHANNEL_SYNC);
  if(radio.available()) { SyncFrame s; radio.read(&s,32); handleSync(s); }
}

void setup(){
  Serial.begin(115200); delay(300); SPI.begin(RF_SCK_PIN,RF_MISO_PIN,RF_MOSI_PIN,RF_CSN_PIN);
  blClear(blacklist); radioCommonBegin(radio);
  Serial.println("BOOT|A|Spectrum-Pipe|single-radio-B");
}

void loop(){
  if(Serial.available()) { String s=Serial.readStringUntil('\n'); s.trim(); if(s.startsWith("SEND:")) queueText(s.substring(5).c_str()); }
  if(!synced || millis()-lastSyncMs>1500) { synced=false; tryRendezvous(); delay(1); return; }

  uint32_t now=logicalUs(); uint32_t sf=now/SUPERFRAME_US; uint32_t phase=now%SUPERFRAME_US; currentSF=sf;
  if(phase<SLOT_SYNC_US) { setRadioChannel(radio,RF_CHANNEL_SYNC); if(radio.available()){SyncFrame s;radio.read(&s,32);handleSync(s);} }
  else if(phase>=AB_RX_START && phase<BC_TX_START) { // A->B
    setRadioChannel(radio,hopChannel(sf,FHSS_SEED_AB,blacklist)); currentChannel=radio.getChannel();
    if(lastTxSF!=sf) sendDataFragment(sf);
  }
  else if(phase>=BC_TX_START && phase<BC_RX_START) { setRadioChannel(radio,hopChannel(sf,FHSS_SEED_BC,blacklist)); currentChannel=radio.getChannel(); }
  else if(phase>=BC_RX_START && phase<AB_TX_START) { setRadioChannel(radio,hopChannel(sf,FHSS_SEED_BC,blacklist)); }
  else { setRadioChannel(radio,hopChannel(sf,FHSS_SEED_AB,blacklist)); receiveDownlink(sf); }

  static uint32_t lastReport=0; if(millis()-lastReport>1000){lastReport=millis();emitStats();}
  delayMicroseconds(100);
}
