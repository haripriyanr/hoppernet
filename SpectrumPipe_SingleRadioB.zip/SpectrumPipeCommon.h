#pragma once
#include <Arduino.h>
#include <SPI.h>
#include <RF24.h>
#include <mbedtls/gcm.h>

// Spectrum-Pipe: single-radio Node B architecture.
// A<->B and B<->C share one RF24 at B and are separated by deterministic time slots.
// The sync beacon is always on the rendezvous channel so a lost hop map can be recovered.

// ---------- Hardware ----------
#ifndef RF_CE_PIN
#define RF_CE_PIN 4
#endif
#ifndef RF_CSN_PIN
#define RF_CSN_PIN 5
#endif
#ifndef RF_SCK_PIN
#define RF_SCK_PIN 18
#endif
#ifndef RF_MISO_PIN
#define RF_MISO_PIN 19
#endif
#ifndef RF_MOSI_PIN
#define RF_MOSI_PIN 23
#endif

// ---------- Nodes ----------
static constexpr uint8_t NODE_A = 1;
static constexpr uint8_t NODE_B = 2;
static constexpr uint8_t NODE_C = 3;

// ---------- RF ----------
static constexpr uint8_t RF_CHANNEL_SYNC = 0;      // rendezvous / recovery channel
static constexpr uint8_t RF_CHANNEL_FIRST = 2;     // 2..125 = 124 channels
static constexpr uint8_t RF_CHANNEL_COUNT = 124;
static constexpr uint8_t RF_CHANNEL_LAST = 125;
static constexpr uint8_t BLACKLIST_BYTES = 16;     // 128 bits, 124 used
static constexpr uint8_t RF_PAYLOAD_SIZE = 32;
static constexpr uint8_t DATA_PLAINTEXT_MAX = 8;   // 32-byte nRF24 packet leaves room for metadata + 8-byte GCM tag
static constexpr uint8_t GCM_TAG_SIZE = 8;
static constexpr uint32_t FHSS_SEED_AB = 0x41B2D931UL;
static constexpr uint32_t FHSS_SEED_BC = 0xC73A91E5UL;

// ---------- Timing ----------
// One superframe is 50 ms. Node B is master.
// 0-4ms   : sync/recovery beacon on fixed rendezvous channel
// 4-16ms  : A -> B data/ACK exchange on AB hop channel
// 16-28ms : B -> C data/ACK exchange on BC hop channel
// 28-40ms : C -> B data/ACK exchange on BC hop channel
// 40-50ms : B -> A data/ACK exchange on AB hop channel
static constexpr uint32_t SUPERFRAME_US = 50000UL;
static constexpr uint32_t SLOT_SYNC_US   = 4000UL;
static constexpr uint32_t SLOT_AB_RX_US  = 12000UL;
static constexpr uint32_t SLOT_BC_TX_US  = 12000UL;
static constexpr uint32_t SLOT_BC_RX_US  = 12000UL;
static constexpr uint32_t SLOT_AB_TX_US  = 8000UL;
static constexpr uint32_t AB_RX_START = SLOT_SYNC_US;
static constexpr uint32_t BC_TX_START = AB_RX_START + SLOT_AB_RX_US;
static constexpr uint32_t BC_RX_START = BC_TX_START + SLOT_BC_TX_US;
static constexpr uint32_t AB_TX_START = BC_RX_START + SLOT_BC_RX_US;

// ---------- Protocol ----------
static constexpr uint16_t SP_MAGIC = 0x5350;
static constexpr uint8_t SP_VERSION = 2;
enum FrameType : uint8_t {
  FT_SYNC = 1,
  FT_DATA = 2,
  FT_ACK = 3,
  FT_CUSTODY = 4,
  FT_DELIVERY = 5,
  FT_MAP = 6
};

struct __attribute__((packed)) DataFrame {
  uint16_t magic;       // 2
  uint8_t version;      // 1
  uint8_t type;         // 1
  uint8_t src;          // 1
  uint8_t dst;          // 1
  uint32_t sf;          // 4
  uint16_t msgId;       // 2
  uint8_t frag;         // 1
  uint8_t total;        // 1
  uint8_t flags;        // 1
  uint8_t len;          // 1
  uint8_t ciphertext[DATA_PLAINTEXT_MAX]; // 8
  uint8_t tag[GCM_TAG_SIZE];              // 8
}; // 32 bytes

struct __attribute__((packed)) AckFrame {
  uint16_t magic;
  uint8_t version;
  uint8_t type;
  uint8_t src;
  uint8_t dst;
  uint32_t sf;
  uint16_t msgId;
  uint8_t frag;
  uint8_t code;         // 1=CUSTODY/RECEIVED, 2=DELIVERY
  uint8_t reserved[10];
}; // 32 bytes

struct __attribute__((packed)) SyncFrame {
  uint16_t magic;
  uint8_t version;
  uint8_t type;
  uint8_t src;
  uint8_t dst;
  uint32_t sf;
  uint16_t mapVersion;
  uint8_t blacklist[BLACKLIST_BYTES];
  uint8_t reserved[2];
}; // 32 bytes

static_assert(sizeof(DataFrame) == 32, "DataFrame must be 32 bytes");
static_assert(sizeof(AckFrame) == 32, "AckFrame must be 32 bytes");
static_assert(sizeof(SyncFrame) == 32, "SyncFrame must be 32 bytes");

// ---------- Demo E2E key ----------
// IMPORTANT: this key is only present in Node A and Node C firmware.
// Node B never needs it and should not be provisioned with it.
static const uint8_t E2E_KEY[16] = {
  0x53,0x50,0x2D,0x45,0x32,0x45,0x2D,0x44,
  0x45,0x4D,0x4F,0x2D,0x32,0x30,0x32,0x36
};

// ---------- Bitset helpers ----------
static inline void blClear(uint8_t *b) { memset(b, 0, BLACKLIST_BYTES); }
static inline bool blGet(const uint8_t *b, uint8_t ch) {
  if (ch < RF_CHANNEL_FIRST || ch > RF_CHANNEL_LAST) return false;
  uint8_t i = ch - RF_CHANNEL_FIRST;
  return (b[i >> 3] >> (i & 7)) & 1U;
}
static inline void blSet(uint8_t *b, uint8_t ch, bool on=true) {
  if (ch < RF_CHANNEL_FIRST || ch > RF_CHANNEL_LAST) return;
  uint8_t i = ch - RF_CHANNEL_FIRST;
  if (on) b[i >> 3] |= (1U << (i & 7));
  else    b[i >> 3] &= ~(1U << (i & 7));
}
static inline uint8_t blCount(const uint8_t *b) {
  uint16_t n=0;
  for (uint8_t i=0;i<RF_CHANNEL_COUNT;i++) if (b[i>>3] & (1U<<(i&7))) n++;
  return (uint8_t)n;
}

static inline uint32_t mix32(uint32_t x) {
  x += 0x9E3779B9UL;
  x = (x ^ (x >> 16)) * 0x85EBCA6BUL;
  x = (x ^ (x >> 13)) * 0xC2B2AE35UL;
  return x ^ (x >> 16);
}

// Deterministic adaptive hop. Each link has its own seed; both endpoints use the same map.
static inline uint8_t hopChannel(uint32_t sf, uint32_t seed, const uint8_t *blacklist) {
  uint16_t healthy = RF_CHANNEL_COUNT - blCount(blacklist);
  if (healthy == 0) return RF_CHANNEL_FIRST;
  uint16_t rank = (uint16_t)(mix32(seed ^ sf) % healthy);
  for (uint8_t ch=RF_CHANNEL_FIRST; ch<=RF_CHANNEL_LAST; ++ch) {
    if (!blGet(blacklist,ch)) {
      if (rank == 0) return ch;
      rank--;
    }
  }
  return RF_CHANNEL_FIRST;
}

static inline void setRadioChannel(RF24 &r, uint8_t ch) {
  r.setChannel(ch);
}

// ---------- CRC-free application authentication ----------
// nRF24 hardware CRC protects the RF packet. GCM authenticates the encrypted payload.
static inline void makeNonce(uint8_t nonce[12], uint8_t src, uint8_t dst,
                             uint32_t sf, uint16_t msgId, uint8_t frag) {
  nonce[0]=0x53; nonce[1]=0x50; nonce[2]=src; nonce[3]=dst;
  memcpy(&nonce[4], &sf, 4);
  memcpy(&nonce[8], &msgId, 2);
  nonce[10]=frag; nonce[11]=SP_VERSION;
}

static inline bool gcmEncrypt(const uint8_t *plain, uint8_t len,
                              uint8_t *cipher, uint8_t tag[8],
                              uint8_t src, uint8_t dst, uint32_t sf,
                              uint16_t msgId, uint8_t frag) {
  if (len > DATA_PLAINTEXT_MAX) return false;
  mbedtls_gcm_context g;
  mbedtls_gcm_init(&g);
  if (mbedtls_gcm_setkey(&g, MBEDTLS_CIPHER_ID_AES, E2E_KEY, 128) != 0) { mbedtls_gcm_free(&g); return false; }
  uint8_t nonce[12]; makeNonce(nonce,src,dst,sf,msgId,frag);
  int rc = mbedtls_gcm_crypt_and_tag(&g, MBEDTLS_GCM_ENCRYPT, len, nonce, sizeof(nonce),
                                     nullptr, 0, plain, cipher, GCM_TAG_SIZE, tag);
  mbedtls_gcm_free(&g);
  return rc == 0;
}

static inline bool gcmDecrypt(const uint8_t *cipher, uint8_t len,
                              const uint8_t tag[8], uint8_t *plain,
                              uint8_t src, uint8_t dst, uint32_t sf,
                              uint16_t msgId, uint8_t frag) {
  if (len > DATA_PLAINTEXT_MAX) return false;
  mbedtls_gcm_context g;
  mbedtls_gcm_init(&g);
  if (mbedtls_gcm_setkey(&g, MBEDTLS_CIPHER_ID_AES, E2E_KEY, 128) != 0) { mbedtls_gcm_free(&g); return false; }
  uint8_t nonce[12]; makeNonce(nonce,src,dst,sf,msgId,frag);
  int rc = mbedtls_gcm_auth_decrypt(&g, len, nonce, sizeof(nonce), nullptr, 0,
                                    tag, GCM_TAG_SIZE, cipher, plain);
  mbedtls_gcm_free(&g);
  return rc == 0;
}

static inline bool validHeader(uint16_t magic, uint8_t version, uint8_t type,
                               uint8_t src, uint8_t dst) {
  if (magic != SP_MAGIC || version != SP_VERSION) return false;
  if (type < FT_SYNC || type > FT_MAP) return false;
  if (src < NODE_A || src > NODE_C) return false;
  if (dst > NODE_C) return false;
  return true;
}

static inline void radioCommonBegin(RF24 &radio) {
  radio.begin();
  radio.setPALevel(RF24_PA_LOW); // safer default for bench testing; raise only if needed
  radio.setDataRate(RF24_250KBPS);
  radio.setChannel(RF_CHANNEL_SYNC);
  radio.setPayloadSize(RF_PAYLOAD_SIZE);
  radio.setAutoAck(false);       // explicit protocol ACKs; no hidden timing dependency
  radio.setCRCLength(RF24_CRC_16);
  radio.openWritingPipe(0xC3C3C3C3C3LL);
  radio.openReadingPipe(1, 0xC3C3C3C3C3LL);
  radio.startListening();
}

static inline bool txFrame(RF24 &radio, const void *frame) {
  radio.stopListening();
  bool ok = radio.write(frame, RF_PAYLOAD_SIZE);
  radio.startListening();
  return ok;
}

static inline bool rxFrame(RF24 &radio, void *frame) {
  if (!radio.available()) return false;
  radio.read(frame, RF_PAYLOAD_SIZE);
  return true;
}
