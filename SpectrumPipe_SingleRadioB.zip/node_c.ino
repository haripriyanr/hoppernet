#include "SpectrumPipeCommon.h"

// Spectrum-Pipe Node C — destination endpoint.
// One nRF24; synchronized to Node B's rendezvous beacon and hop schedule.
RF24 radio(RF_CE_PIN, RF_CSN_PIN);
static uint8_t blacklist[BLACKLIST_BYTES];
static bool synced=false;
static int32_t clockOffsetUs=0;
static uint32_t lastSyncMs=0;
static uint32_t currentSF=0;
static uint16_t mapVersion=1;
static uint16_t nextMsgId=1;
static uint16_t txMsgId=0;
static uint8_t txFrag=0,txTotal=0;
static char txMessage[256];
static uint16_t txMessageLen=0;
static uint32_t lastTxSF=0xFFFFFFFFUL;
static uint32_t rxFragments=0,custodyAcks=0,delivered=0,retries=0;
static uint8_t currentChannel=RF_CHANNEL_SYNC;

struct Assembly { uint16_t msgId; uint8_t total; uint32_t bitmap; uint16_t length; char data[256]; bool active; };
static Assembly assembly={};

static void stats(){Serial.printf("STAT|C|sync=%u|sf=%lu|ch=%u|map=%u|rx=%lu|custody=%lu|del=%lu|retry=%lu|queue=%u\n",synced,(unsigned long)currentSF,currentChannel,mapVersion,(unsigned long)rxFragments,(unsigned long)custodyAcks,(unsigned long)delivered,(unsigned long)retries,txMessageLen?1:0);}
static uint32_t logicalUs(){return (uint32_t)((int64_t)micros()+clockOffsetUs);}

static void queueReply(const char *s){if(!s||!*s)return;size_t n=strlen(s);if(n>sizeof(txMessage))n=sizeof(txMessage);memcpy(txMessage,s,n);txMessageLen=n;txMsgId=nextMsgId++;txFrag=0;txTotal=(uint8_t)((n+DATA_PLAINTEXT_MAX-1)/DATA_PLAINTEXT_MAX);if(!txTotal)txTotal=1;Serial.printf("QUEUE|C|msg=%u|bytes=%u|frags=%u\n",txMsgId,txMessageLen,txTotal);}

static void handleSync(const SyncFrame&s){if(!validHeader(s.magic,s.version,s.type,s.src,s.dst)||s.src!=NODE_B||s.type!=FT_SYNC)return;memcpy(blacklist,s.blacklist,BLACKLIST_BYTES);mapVersion=s.mapVersion;uint32_t local=micros();currentSF=s.sf;clockOffsetUs=(int32_t)(s.sf*SUPERFRAME_US)-(int32_t)local;synced=true;lastSyncMs=millis();Serial.printf("SYNC|C|sf=%lu|map=%u|blacklist=%u\n",(unsigned long)currentSF,mapVersion,blCount(blacklist));}

static void sendFragment(uint32_t sf){
  if(!txMessageLen||!txTotal)return;
  uint8_t off=txFrag*DATA_PLAINTEXT_MAX;if(off>=txMessageLen)return;uint8_t len=(uint8_t)min((uint16_t)DATA_PLAINTEXT_MAX,(uint16_t)(txMessageLen-off));
  DataFrame f{};f.magic=SP_MAGIC;f.version=SP_VERSION;f.type=FT_DATA;f.src=NODE_C;f.dst=NODE_B;f.sf=sf;f.msgId=txMsgId;f.frag=txFrag;f.total=txTotal;f.flags=1;f.len=len;
  if(!gcmEncrypt((uint8_t*)txMessage+off,len,f.ciphertext,f.tag,NODE_C,NODE_A,sf,txMsgId,txFrag))return;
  setRadioChannel(radio,hopChannel(sf,FHSS_SEED_BC,blacklist));currentChannel=radio.getChannel();if(txFrame(radio,&f)){}else retries++;
}

static void handleAck(const AckFrame&a){if(a.magic!=SP_MAGIC||a.version!=SP_VERSION||a.dst!=NODE_C)return;if(a.type==FT_CUSTODY&&a.msgId==txMsgId&&a.frag==txFrag){custodyAcks++;if(txFrag+1<txTotal)txFrag++;else{txMessageLen=0;txFrag=0;txTotal=0;}}}

static void receiveForward(uint32_t sf){
  uint32_t end=micros()+9000;while((int32_t)(micros()-end)<0){if(!radio.available()){delayMicroseconds(50);continue;}uint8_t raw[32];radio.read(raw,32);uint8_t type=raw[3];
    if(type==FT_CUSTODY){AckFrame a;memcpy(&a,raw,32);handleAck(a);continue;}
    if(type!=FT_DATA)continue;DataFrame d;memcpy(&d,raw,32);if(d.magic!=SP_MAGIC||d.version!=SP_VERSION||d.type!=FT_DATA||d.src!=NODE_B||d.dst!=NODE_C||d.len>DATA_PLAINTEXT_MAX)continue;
    uint8_t plain[8];if(!gcmDecrypt(d.ciphertext,d.len,d.tag,plain,NODE_A,NODE_C,d.sf,d.msgId,d.frag)){Serial.printf("SECURITY|C|AUTH_FAIL|msg=%u|frag=%u\n",d.msgId,d.frag);continue;}
    rxFragments++;
    if(!assembly.active||assembly.msgId!=d.msgId){memset(&assembly,0,sizeof(assembly));assembly.active=true;assembly.msgId=d.msgId;assembly.total=d.total;}
    if(d.frag<32 && !(assembly.bitmap&(1UL<<d.frag))){uint16_t off=d.frag*DATA_PLAINTEXT_MAX;memcpy(assembly.data+off,plain,d.len);assembly.bitmap|=(1UL<<d.frag);if(off+d.len>assembly.length)assembly.length=off+d.len;}
    AckFrame ack{};ack.magic=SP_MAGIC;ack.version=SP_VERSION;ack.type=FT_DELIVERY;ack.src=NODE_C;ack.dst=NODE_B;ack.sf=sf;ack.msgId=d.msgId;ack.frag=d.frag;ack.code=2;setRadioChannel(radio,hopChannel(sf,FHSS_SEED_BC,blacklist));txFrame(radio,&ack);
    if(assembly.total<=32){uint32_t want=assembly.total==32?0xFFFFFFFFUL:((1UL<<assembly.total)-1);if((assembly.bitmap&want)==want){Serial.printf("DELIVER|C|msg=%u|bytes=%u|data=",assembly.msgId,assembly.length);for(uint16_t i=0;i<assembly.length;i++)Serial.write(assembly.data[i]);Serial.println();delivered++;memset(&assembly,0,sizeof(assembly));}}
  }
}

static void rendezvous(){setRadioChannel(radio,RF_CHANNEL_SYNC);if(radio.available()){SyncFrame s;radio.read(&s,32);handleSync(s);}}

void setup(){Serial.begin(115200);delay(300);SPI.begin(RF_SCK_PIN,RF_MISO_PIN,RF_MOSI_PIN,RF_CSN_PIN);blClear(blacklist);radioCommonBegin(radio);Serial.println("BOOT|C|Spectrum-Pipe|single-radio-B");}

void loop(){
  if(Serial.available()){String s=Serial.readStringUntil('\n');s.trim();if(s.startsWith("SEND:"))queueReply(s.substring(5).c_str());}
  if(!synced||millis()-lastSyncMs>1500){synced=false;rendezvous();delay(1);return;}
  uint32_t now=logicalUs();uint32_t sf=now/SUPERFRAME_US;uint32_t phase=now%SUPERFRAME_US;currentSF=sf;
  if(phase<SLOT_SYNC_US){setRadioChannel(radio,RF_CHANNEL_SYNC);if(radio.available()){SyncFrame s;radio.read(&s,32);handleSync(s);}}
  else if(phase>=AB_RX_START&&phase<BC_TX_START){setRadioChannel(radio,hopChannel(sf,FHSS_SEED_AB,blacklist));}
  else if(phase>=BC_TX_START&&phase<BC_RX_START){setRadioChannel(radio,hopChannel(sf,FHSS_SEED_BC,blacklist));receiveForward(sf);}
  else if(phase>=BC_RX_START&&phase<AB_TX_START){setRadioChannel(radio,hopChannel(sf,FHSS_SEED_BC,blacklist));}
  else {setRadioChannel(radio,hopChannel(sf,FHSS_SEED_AB,blacklist));}
  static uint32_t lastTxSF=0xFFFFFFFFUL;if(phase>=BC_RX_START&&phase<AB_TX_START&&lastTxSF!=sf){sendFragment(sf);lastTxSF=sf;}
  static uint32_t lastReport=0;if(millis()-lastReport>1000){lastReport=millis();stats();}
  delayMicroseconds(100);
}
