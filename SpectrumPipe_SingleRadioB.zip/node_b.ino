#include "SpectrumPipeCommon.h"

// Spectrum-Pipe Node B — single-radio intelligent relay/master.
// The radio is time-multiplexed between A and C; queues guarantee store-and-forward.
RF24 radio(RF_CE_PIN, RF_CSN_PIN);

static uint8_t blacklist[BLACKLIST_BYTES];
static uint8_t badStreak[RF_CHANNEL_COUNT];
static uint8_t goodStreak[RF_CHANNEL_COUNT];
static uint16_t mapVersion=1;
static uint32_t sfNow=0;
static uint8_t currentChannel=RF_CHANNEL_SYNC;
static uint32_t lastRxA=0,lastRxC=0;
static uint32_t rxA=0,rxC=0,txC=0,txA=0,ackA=0,ackC=0;
static uint32_t bufAtoC=0,bufCtoA=0;
static uint32_t blacklistedEvents=0;

struct QueueItem { DataFrame frame; uint32_t queuedSF; bool used; };
static QueueItem qAC[64];
static QueueItem qCA[64];
static uint8_t qACHead=0,qACTail=0,qACCount=0;
static uint8_t qCAHead=0,qCATail=0,qCACount=0;

static void telemetry(){
  Serial.printf("STAT|B|sf=%lu|ch=%u|map=%u|black=%u|ABrx=%lu|BCtx=%lu|BCrx=%lu|ABtx=%lu|QAC=%u|QCA=%u\n",
   (unsigned long)sfNow,currentChannel,mapVersion,blCount(blacklist),
   (unsigned long)rxA,(unsigned long)txC,(unsigned long)rxC,(unsigned long)txA,qACCount,qCACount);
}

static bool qPush(QueueItem *q,uint8_t &head,uint8_t &count,const DataFrame &f){
  if(count>=64) return false;
  q[head].frame=f; q[head].queuedSF=sfNow; q[head].used=true; head=(head+1)%64; count++; return true;
}
static bool qPeek(QueueItem *q,uint8_t tail,uint8_t count,DataFrame &f){if(!count)return false;f=q[tail].frame;return true;}
static void qPop(uint8_t &tail,uint8_t &count){if(count){tail=(tail+1)%64;count--;}}

static void scoreSuccess(uint8_t ch){
  if(ch<RF_CHANNEL_FIRST||ch>RF_CHANNEL_LAST)return;
  uint8_t i=ch-RF_CHANNEL_FIRST;
  if(goodStreak[i]<250)goodStreak[i]++;
  if(badStreak[i])badStreak[i]--;
  if(blGet(blacklist,ch) && goodStreak[i]>=8){blSet(blacklist,ch,false);goodStreak[i]=0;mapVersion++;Serial.printf("EVENT|B|CHANNEL_RECOVER|ch=%u|map=%u\n",ch,mapVersion);}
}
static void scoreFailure(uint8_t ch){
  if(ch<RF_CHANNEL_FIRST||ch>RF_CHANNEL_LAST)return;
  uint8_t i=ch-RF_CHANNEL_FIRST;
  if(badStreak[i]<250)badStreak[i]++;
  goodStreak[i]=0;
  // Multiple consecutive link failures are stronger evidence than one missed packet.
  if(badStreak[i]>=4 && !blGet(blacklist,ch) && blCount(blacklist)<(RF_CHANNEL_COUNT-4)){
    blSet(blacklist,ch,true); mapVersion++; blacklistedEvents++;
    Serial.printf("EVENT|B|BLACKLIST|ch=%u|map=%u\n",ch,mapVersion);
  }
}

static void tune(uint8_t ch){if(currentChannel!=ch){radio.setChannel(ch);currentChannel=ch;}}

static void sendSync(){
  SyncFrame s{}; s.magic=SP_MAGIC;s.version=SP_VERSION;s.type=FT_SYNC;s.src=NODE_B;s.dst=0;
  s.sf=sfNow;s.mapVersion=mapVersion;memcpy(s.blacklist,blacklist,BLACKLIST_BYTES);
  tune(RF_CHANNEL_SYNC);txFrame(radio,&s);
}

static void sendAck(uint8_t dst,uint32_t sf,uint16_t msgId,uint8_t frag,uint8_t type){
  AckFrame a{};a.magic=SP_MAGIC;a.version=SP_VERSION;a.type=type;a.src=NODE_B;a.dst=dst;a.sf=sf;a.msgId=msgId;a.frag=frag;a.code=(type==FT_DELIVERY?2:1);
  txFrame(radio,&a);
}

static void receiveFromA(){
  tune(hopChannel(sfNow,FHSS_SEED_AB,blacklist));
  uint32_t deadline=micros()+9000;
  bool got=false;
  while((int32_t)(micros()-deadline)<0){
    if(!radio.available()) { delayMicroseconds(50); continue; }
    uint8_t raw[32];radio.read(raw,32);DataFrame d;memcpy(&d,raw,32);
    if(d.magic!=SP_MAGIC||d.version!=SP_VERSION||d.type!=FT_DATA||d.src!=NODE_A||d.dst!=NODE_B||d.len>DATA_PLAINTEXT_MAX)continue;
    got=true;rxA++;lastRxA=millis();
    if(qPush(qAC,qACHead,qACCount,d)){bufAtoC=qACCount;sendAck(NODE_A,sfNow,d.msgId,d.frag,FT_CUSTODY);ackA++;Serial.printf("CUSTODY|B|A->C|msg=%u|frag=%u|Q=%u\n",d.msgId,d.frag,qACCount);}
    else Serial.println("DROP|B|A->C|QUEUE_FULL");
    break;
  }
  if(got) scoreSuccess(currentChannel); else scoreFailure(currentChannel);
}

static void receiveFromC(){
  tune(hopChannel(sfNow,FHSS_SEED_BC,blacklist));
  uint32_t deadline=micros()+9000;bool got=false;
  while((int32_t)(micros()-deadline)<0){
    if(!radio.available()){delayMicroseconds(50);continue;}
    uint8_t raw[32];radio.read(raw,32);DataFrame d;memcpy(&d,raw,32);
    if(d.magic!=SP_MAGIC||d.version!=SP_VERSION||d.type!=FT_DATA||d.src!=NODE_C||d.dst!=NODE_B||d.len>DATA_PLAINTEXT_MAX)continue;
    got=true;rxC++;lastRxC=millis();
    if(qPush(qCA,qCAHead,qCACount,d)){bufCtoA=qCACount;sendAck(NODE_C,sfNow,d.msgId,d.frag,FT_CUSTODY);ackC++;Serial.printf("CUSTODY|B|C->A|msg=%u|frag=%u|Q=%u\n",d.msgId,d.frag,qCACount);}
    else Serial.println("DROP|B|C->A|QUEUE_FULL");
    break;
  }
  if(got)scoreSuccess(currentChannel);else scoreFailure(currentChannel);
}

static bool forwardOne(QueueItem *q,uint8_t &tail,uint8_t count,uint8_t dst,uint32_t seed,bool forwardToC){
  if(!count)return false;
  DataFrame f=q[tail].frame;
  // Rewrite only the network hop endpoints. The encrypted payload and original
  // sf/msgId/frag stay untouched so the destination can verify the A<->C E2E nonce.
  f.src=NODE_B;
  f.dst=dst;
  tune(hopChannel(sfNow,seed,blacklist));
  bool ok=txFrame(radio,&f);
  if(!ok){scoreFailure(currentChannel);return false;}
  uint32_t end=micros()+2500;bool delivered=false;
  while((int32_t)(micros()-end)<0){
    if(!radio.available()){delayMicroseconds(40);continue;}
    uint8_t raw[32];radio.read(raw,32);AckFrame a;memcpy(&a,raw,32);
    if(a.magic==SP_MAGIC&&a.version==SP_VERSION&&a.type==FT_DELIVERY&&a.src==dst&&a.dst==NODE_B&&a.msgId==f.msgId&&a.frag==f.frag){delivered=true;break;}
  }
  if(delivered){qPop(tail,count);if(forwardToC)txC++;else txA++;scoreSuccess(currentChannel);Serial.printf("DELIVER|B|%s|msg=%u|frag=%u|Q=%u\n",forwardToC?"A->C":"C->A",f.msgId,f.frag,count);}
  else {scoreFailure(currentChannel);Serial.printf("RETRY|B|%s|msg=%u|frag=%u\n",forwardToC?"A->C":"C->A",f.msgId,f.frag);}
  return delivered;
}

void setup(){
  Serial.begin(115200);delay(300);SPI.begin(RF_SCK_PIN,RF_MISO_PIN,RF_MOSI_PIN,RF_CSN_PIN);blClear(blacklist);memset(badStreak,0,sizeof(badStreak));memset(goodStreak,0,sizeof(goodStreak));radioCommonBegin(radio);Serial.println("BOOT|B|Spectrum-Pipe|ONE-RADIO-RELAY");
}

void loop(){
  uint32_t now=micros();sfNow=now/SUPERFRAME_US;uint32_t phase=now%SUPERFRAME_US;
  static uint32_t lastSF=0xFFFFFFFFUL;
  if(sfNow!=lastSF){lastSF=sfNow;sendSync();}

  if(phase>=AB_RX_START && phase<BC_TX_START){receiveFromA();}
  else if(phase>=BC_TX_START && phase<BC_RX_START){forwardOne(qAC,qACTail,qACCount,NODE_C,FHSS_SEED_BC,true);}
  else if(phase>=BC_RX_START && phase<AB_TX_START){receiveFromC();}
  else if(phase>=AB_TX_START){forwardOne(qCA,qCATail,qCACount,NODE_A,FHSS_SEED_AB,false);}

  // Probe one non-blacklisted channel only during the 48-50 ms guard.
  // This is energy observation only; it never generates interference.
  static uint32_t lastProbeSF=0;
  if(phase>=48000UL && sfNow-lastProbeSF>=20){
    lastProbeSF=sfNow;
    uint8_t probe=(uint8_t)(RF_CHANNEL_FIRST+(mix32(sfNow*0x9E37u)%RF_CHANNEL_COUNT));
    if(!blGet(blacklist,probe)){
      tune(probe); delayMicroseconds(250);
      bool energy=radio.testRPD();
      if(energy){ uint8_t i=probe-RF_CHANNEL_FIRST; if(badStreak[i]<250)badStreak[i]++; if(badStreak[i]>=6)scoreFailure(probe); }
    }
  }
  static uint32_t lastTele=0;if(millis()-lastTele>1000){lastTele=millis();telemetry();}
  delayMicroseconds(50);
}
