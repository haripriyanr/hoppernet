SPECTRUM-PIPE SINGLE-RADIO NODE-B BUILD

Files:
  SpectrumPipeCommon.h
  node_a.ino
  node_b.ino
  node_c.ino

Architecture:
  A: one nRF24
  B: one nRF24 (time-multiplexed intelligent relay)
  C: one nRF24

B superframe (50 ms):
  0-4 ms    sync beacon on fixed rendezvous channel 0
  4-16 ms   A -> B
  16-28 ms  B -> C
  28-40 ms  C -> B
  40-48 ms  B -> A
  48-50 ms  guard / RPD probe

FHSS:
  124 data channels (2..125), deterministic per-link hop maps.
  B updates a 124-bit blacklist from packet failures and RPD probes.
  B broadcasts the full blacklist in every sync beacon.
  A/B use FHSS_SEED_AB; B/C use FHSS_SEED_BC.

Store-and-forward:
  B keeps two SRAM queues (A->C and C->A).
  B sends a CUSTODY ACK after accepting a frame.
  The queued frame is removed only after a DELIVERY ACK from the destination.

Security:
  A and C use AES-GCM through ESP32 mbedTLS. B never has the E2E key.
  The demo key is in SpectrumPipeCommon.h and should be changed before judging.
  8-byte authentication tags are used because the nRF24 payload is limited to 32 bytes.

Important:
  This is an engineering prototype for controlled/authorized RF testing.
  It detects RF energy using nRF24 RPD and link statistics; it does not generate interference.
  RPD is an energy-above-threshold indicator, not calibrated RSSI.

Arduino IDE:
  Install RF24 library and an ESP32 Arduino core with mbedTLS GCM headers.
  Put all four files in the same sketch folder.
  Open each .ino separately when compiling/flashing.

Default nRF24 wiring (ESP32 VSPI):
  VCC 3.3V, GND GND, SCK 18, MISO 19, MOSI 23, CE 4, CSN 5.
  Use a local 3.3V supply and decoupling capacitor at each nRF24 module.

Serial:
  115200 baud.
  Node A/C accept: SEND:<message>
  Telemetry is line-oriented and suitable for a Python dashboard.
